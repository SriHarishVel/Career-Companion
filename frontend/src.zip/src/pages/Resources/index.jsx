import { useEffect, useState } from "react";
import { useLocation } from "react-router-dom";

import LoadingState from "../../components/LoadingState";
import useQueryParams from "../../hooks/useQueryParams";

import ResourceCard from "./components/ResourceCard";
import ResourceFilters from "./components/ResourceFilters";

import { getGoals } from "../../services/goalService";
import {
  getResources,
  createResource,
  updateResource,
  deleteResource,
} from "../../services/resourceService";
import { getSkills } from "../../services/skillService";

import "./index.css";

function Resources() {
  const location = useLocation();

  const { getParam, setParams, clearParams } = useQueryParams();

  const [resources, setResources] = useState([]);
  const [skills, setSkills] = useState([]);
  const [goals, setGoals] = useState([]);

  const [loading, setLoading] = useState(true);
  const [errorMsg, setErrorMsg] = useState("");

  const searchResource = getParam("search") || "";
  const sortOption = getParam("sort") || "default";
  const filterOption = getParam("type") || "All";
  const skillFilter = getParam("skill") || location.state?.skillId || "All";

  function getResourceParams() {
    return {
      search: searchResource || undefined,
      type: filterOption === "All" ? undefined : filterOption,
      skill: skillFilter === "All" ? undefined : skillFilter,
      sort: sortOption === "default" ? undefined : sortOption,
    };
  }

  useEffect(() => {
    let cancelled = false;

    async function fetchResources() {
      try {
        setLoading(true);
        setErrorMsg("");

        const data = await getResources(getResourceParams());

        if (!cancelled) {
          setResources(data);
        }
      } catch (error) {
        if (!cancelled) {
          console.error("Failed to load resources:", error);

          setErrorMsg(
            error.response?.data?.message ||
              "Unable to load your resources. Please try again.",
          );
        }
      } finally {
        if (!cancelled) {
          setLoading(false);
        }
      }
    }

    fetchResources();

    return () => {
      cancelled = true;
    };
  }, [searchResource, sortOption, filterOption, skillFilter]);

  useEffect(() => {
    let cancelled = false;

    async function fetchSupportingData() {
      try {
        const [skillData, goalData] = await Promise.all([
          getSkills(),
          getGoals(),
        ]);

        if (!cancelled) {
          setSkills(skillData);
          setGoals(goalData);
        }
      } catch (error) {
        if (!cancelled) {
          console.error("Failed to load resource data:", error);

          setErrorMsg(
            error.response?.data?.message ||
              "Unable to load resource data. Please try again.",
          );
        }
      }
    }

    fetchSupportingData();

    return () => {
      cancelled = true;
    };
  }, []);

  function handleSearchChange(value) {
    setParams({
      search: value || "",
    });
  }

  function handleSortChange(value) {
    setParams({
      sort: value === "default" ? "" : value,
    });
  }

  function handleTypeChange(value) {
    setParams({
      type: value === "All" ? "" : value,
    });
  }

  function handleSkillChange(value) {
    setParams({
      skill: value === "All" ? "" : value,
    });
  }

  function clearFilters() {
    clearParams(["search", "sort", "type", "skill"]);
  }

  function getParentGoalTitle(skill) {
    if (!skill?.secondaryGoal) {
      return "";
    }

    const parentGoalId =
      typeof skill.secondaryGoal === "object"
        ? skill.secondaryGoal.parentGoal?._id || skill.secondaryGoal.parentGoal
        : null;

    if (!parentGoalId) {
      return "";
    }

    const parentGoal = goals.find((goal) => goal._id === parentGoalId);

    return parentGoal ? parentGoal.title : "";
  }

  async function refreshResources() {
    try {
      setErrorMsg("");

      const data = await getResources(getResourceParams());

      setResources(data);
    } catch (error) {
      console.error("Failed to refresh resources:", error);

      setErrorMsg(
        error.response?.data?.message ||
          "Unable to refresh your resources. Please try again.",
      );
    }
  }

  async function handleCreateResource(resourceData) {
    try {
      await createResource(resourceData);
      await refreshResources();
    } catch (error) {
      console.error("Failed to create resource:", error);

      setErrorMsg(
        error.response?.data?.message ||
          "Unable to create the resource. Please try again.",
      );
    }
  }

  async function handleUpdateResource(resourceId, resourceData) {
    try {
      await updateResource(resourceId, resourceData);
      await refreshResources();
    } catch (error) {
      console.error("Failed to update resource:", error);

      setErrorMsg(
        error.response?.data?.message ||
          "Unable to update the resource. Please try again.",
      );
    }
  }

  async function handleDeleteResource(resourceId) {
    try {
      await deleteResource(resourceId);
      await refreshResources();
    } catch (error) {
      console.error("Failed to delete resource:", error);

      setErrorMsg(
        error.response?.data?.message ||
          "Unable to delete the resource. Please try again.",
      );
    }
  }

  if (loading) {
    return (
      <div className="container">
        <h1>Resources</h1>

        <LoadingState message="Loading your resources..." />
      </div>
    );
  }

  return (
    <div className="container">
      <div className="page-header">
        <h1>Resources</h1>
      </div>

      {errorMsg && (
        <div className="resource-error-message" role="alert">
          {errorMsg}
        </div>
      )}

      <ResourceFilters
        searchResource={searchResource}
        setSearchResource={handleSearchChange}
        sortOption={sortOption}
        setSortOption={handleSortChange}
        filterOption={filterOption}
        setFilterOption={handleTypeChange}
        skillFilter={skillFilter}
        setSkillFilter={handleSkillChange}
        skills={skills}
        getParentGoalTitle={getParentGoalTitle}
        onClearFilters={clearFilters}
      />

      <div className="resources-grid">
        {resources.length > 0 ? (
          resources.map((resource) => (
            <ResourceCard
              key={resource._id}
              resource={resource}
              onUpdate={handleUpdateResource}
              onDelete={handleDeleteResource}
            />
          ))
        ) : (
          <div className="empty-state">
            <h3>No resources found</h3>

            <p>Add a resource or adjust your filters.</p>
          </div>
        )}
      </div>
    </div>
  );
}

export default Resources;
