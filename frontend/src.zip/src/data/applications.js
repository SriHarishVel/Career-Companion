// Sample applications shown before the user adds their own.
const initialApplications = [
    {
        id: 1,
        company: "Zoho",
        role: "Software Developer",
        status: "Applied",
        appliedDate: "2026-06-21",
        notes: "",
        applicationUrl: "",
        interviewRounds: [],
        primaryGoalId: null,
        lastUpdated: Date.now()
    },
    {
        id: 2,
        company: "Freshworks",
        role: "Backend Engineer",
        status: "Offer",
        appliedDate: "2026-06-18",
        notes: "",
        applicationUrl: "",
        interviewRounds: [],
        primaryGoalId: null,
        lastUpdated: Date.now()
    },
    {
        id: 3,
        company: "Chargebee",
        role: "Full Stack Developer",
        status: "Rejected",
        appliedDate: "2026-06-10",
        notes: "",
        applicationUrl: "",
        interviewRounds: [],
        primaryGoalId: null,
        lastUpdated: Date.now()
    }
];

export default initialApplications;